TS SMART GAUGE RACING — ANDROID CLOUD BUILD PACK
Target: ESP32-2432S028 CYD, ST7789 (7789 label), ESP32-WROOM-32, 4MB flash.

Project layout:
- platformio.ini
- TFT_eSPI_User_Setup.h
- src/main.cpp

Build on GitHub Codespaces (phone browser):
1) Create a GitHub repository and upload this ZIP file to it.
2) Open repository > Code > Codespaces > Create codespace on main.
3) In the Codespaces terminal:
   unzip TS_SmartGauge_CYD_RACING_AndroidBuild.zip -d project
   cd project
   python3 -m venv .venv
   source .venv/bin/activate
   pip install platformio
   pio run
4) Output directory:
   .pio/build/esp32-2432s028-st7789/
   Expected files: firmware.bin, bootloader.bin, partitions.bin, boot_app0.bin
5) Download the binaries to Android using the Codespaces file explorer or browser download.

Important:
- This project is source code, not precompiled firmware.
- The compiler output must be checked for success before flashing.
- Flash addresses for standard ESP32 Arduino 4MB build:
  bootloader.bin  0x1000
  partitions.bin  0x8000
  boot_app0.bin   0xE000
  firmware.bin    0x10000
  Confirm the generated flash_args / platformio upload command in the actual build if platform versions differ.
- If using a flasher app, add all generated files with their respective offsets; do not put bootloader at 0x0.
- The board's 2.8 inch panel is 240x320 native; sketch uses rotation 1 for 320x240 landscape.
- Display pins: SCLK 14, MOSI 13, MISO 12, CS 15, DC 2, BL 21, RST -1.
- Color order BGR is configured. Inversion may vary by ST7789 panel batch; if image is inverted, adjust TFT_INVERSION_ON/OFF and rebuild.
- Demo telemetry only: send S85,R6500,G3,F72,T88,V13.8 at 115200 baud.
- Real motorcycle sensor inputs are NOT implemented. Never connect 12V, ignition coil or spark-plug signals directly to ESP32 GPIO.
